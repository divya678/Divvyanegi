
$(document).ready(function () {

    $('#submit').click(function () {

       let fname= validatefirstname();
       let lname= validatelastname();
      let gender=  validategender();
        let chbox=validatecourse();
      let email=  validateemail();

      console.log({
        FirstName: fname, LastName: lname,
        Email: email, Gender: gender, Course: chbox
    });
    return false;

})



    $('#fnamechk').hide();
    function validatefirstname() {
        let firstname = $('#fname').val();

        if (firstname.length == '') {
            $('#fnamechk').show();
            return false;
        }
        else {
            $('#fnamechk').hide();
            console.log( firstname);
            return firstname;
        }
    }

    $('#lnamechk').hide();

    function validatelastname() {
        let lastname = $('#lname').val();
        if (lastname.length == '') {
            $('#lnamechk').show();
            return false;
        }
        else {
            $('#lnamechk').hide();
            console.log(lastname);
            return lastname;
        }
    }

    $('#genderchk').hide();

    function validategender() {
        let gender = $('#gender').val();
        if (gender == "select") {
            $('#genderchk').show();
            return false;
        } else {
            $('#genderchk').hide();
            console.log( gender);
            return gender;
        }
    }

    $('#emailchk').hide();

    function validateemail() {
        let email = $('#email').val();
        let regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

        if ((email == '') || (!regex.test(email))) {
            $('#emailchk').show();
            return false;
        } else {
            $('#emailchk').hide();
            console.log( email);
            return email;
        }
    }

    $('#coursechk').hide();
    function validatecourse() {
        var course = [];
        $.each($("input[name='chbox']:checked"), function () {
            course.push($(this).val());
        });
        if (course == 0) {
            $('#coursechk').show();
            return false;
        } else {
            $('#coursechk').hide();
            console.log("Course: " + course);
            return course;
        }
    }
});