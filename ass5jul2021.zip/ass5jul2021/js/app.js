
$(document).ready(function () {

    $('#submit').click(function () {

        validatefirstname();
        validatelastname();
        validategender();
        validatecourse();
        validateemail();
    });

    $('#fnamechk').hide();
    function validatefirstname() {
        let firstname = $('#fname').val();

        if (firstname.length == '') {
            $('#fnamechk').show();
            return false;
        }
        else {
            $('#fnamechk').hide();
            console.log("Firstname " + firstname);
        }
    }

    $('#lnamechk').hide();

    function validatelastname() {
        let lastname = $('#lname').val();
        if (lastname.length == '') {
            $('#lnamechk').show();
            return false;
        }
        else {
            $('#lnamechk').hide();
            console.log("Lastname " + lastname);
        }
    }

    $('#genderchk').hide();

    function validategender() {
        let gender = $('#gender').val();
        if (gender == "select") {
            $('#genderchk').show();
            return false;
        } else {
            $('#genderchk').hide();
            console.log("Gender: " + gender);
        }
    }

    $('#emailchk').hide();

    function validateemail() {
        let email = $('#email').val();
        let regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

        if ((email == '') || (!regex.test(email))) {
            $('#emailchk').show();
            return false;
        } else {
            $('#emailchk').hide();
            console.log("Email: " + email);
        }
    }

    $('#coursechk').hide();
    function validatecourse() {
        var course = [];
        $.each($("input[name='chbox']:checked"), function () {
            course.push($(this).val());
        });
        if (course == 0) {
            $('#coursechk').show();
            return false;
        } else {
            $('#coursechk').hide();
            console.log("Course: " + course);
        }
    }
});