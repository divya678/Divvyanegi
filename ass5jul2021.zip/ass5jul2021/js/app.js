
$(document).ready(function () {

    $('#submit').click(function () {
        
        validatefirstname();
        validatelastname();
        validategender() ;
        validatecourse();
        validateemail();
       
       
    });

    // Validate Username
    $('#fnamechk').hide();

    let firstnameerror = true;

    function validatefirstname() {
        let firstname = $('#fname').val();

        if (firstname.length == '') {
            $('#fnamechk').show();
            
            firstnameerror = false;
            return false;
        }
        else {
            $('#fnamechk').hide();
            console.log("Firstname "+firstname);
          
        }

    }
    $('#lnamechk').hide();

    let lnameerror = true;
    function validatelastname() {
        let lastname = $('#lname').val();
        if (lastname.length == '') {
            $('#lnamechk').show();
            lnameerror = false;
            return false;
        }
        else {
            $('#lnamechk').hide();
            console.log("Lastname "+lastname);
        }

    }
    //validate gender

    $('#genderchk').hide();
    let gendererror = true;

    function validategender() {
        let gender = $('#gender').val();

            if (gender == "select") {
                
                $('#genderchk').show();
                gendererror = false;

                return false;
        } else {
            $('#genderchk').hide();
            console.log("Gender: "+gender);
        }
    }
     
    $('#emailchk').hide();
    let emailerror = true;
    function validateemail() {
        let email = $('#email').val();
        let regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

        if ((email == '') || (!regex.test(email))) {
            $('#emailchk').show();
            emailerror = false;

            return false;
        } else {
            $('#emailchk').hide();
            console.log("Email: "+email);
        }


    }

    // Validate course

    $('#coursechk').hide();
    let courseerror = true;

    function validatecourse() {
        let course = $('input[name="chbox"]:checked').val();
       

        if (course == undefined) {
            $('#coursechk').show();
            courseerror = false;

            return false;
        } else {
            $('#coursechk').hide();
            console.log("Course: "+course);
        }
    }

    

    // Submitt button
               
   
});