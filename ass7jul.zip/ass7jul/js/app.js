$(document).ready(function () {
    const ul = $("#todo");
    function add() {
        let text = $('#list').val();
        
        if (!text == "") {
            $('#err').text("")
            $('#list').val("");

            $(ul).append('<li>' + text + '<button class="remove">delete</button></li>')
        }
        else
        $('#err').text("Kindly enter the text")
       
    }

    $(ul).on('click', ".remove", function () {
        $(this).parent('li').remove();
    })

    $('#add').click(function () {
        add();
    })
})