

const express=require('express');
const server=express();
const port=3000;



server.get('/index.html',(req,resp)=>{
    resp.sendFile(__dirname+'/index.html');
})


server.get('/css/style.css',(req,resp)=>{
    resp.sendFile(__dirname+'/css/style.css');
})

server.get('/js/app.js',(req,resp)=>{
    resp.sendFile(__dirname+'/js/app.js');
})
server.listen(port,()=>{
console.log("Server Started ");
console.log("http://localhost:3000/index.html");
});
    
    