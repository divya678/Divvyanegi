

const express=require('express');
const server=express();
server.use(express.json())
server.use(express.urlencoded({extended:true}));
const port=3000;
//GET /welcome
server.post('/welcome',(req,resp)=>{
    resp.sendFile(__dirname+'/welcome.html');
    const Firstname=req.body.fname;
    const lastname=req.body.lname;  
    const gender=req.body.gender;
    const email=req.body.email;
    const chbox=req.body.chbox;
     console.log("firstname "+Firstname);
     console.log("Lastname "+lastname);
     console.log("Gender "+gender);
     console.log("Email "+email);
    console.log("Course "+chbox);
})


//Get /index.html
server.get('/index.html',(req,resp)=>{
    resp.sendFile(__dirname+'/index.html');
})


server.get('/css/style.css',(req,resp)=>{
    resp.sendFile(__dirname+'/css/style.css');
})
//Get /js/app.js
server.get('/js/app.js',(req,resp)=>{
    resp.sendFile(__dirname+'/js/app.js');
})
server.listen(port,()=>{
console.log("Server Started ");
console.log("http://localhost:3000/index.html");
});
    
    